<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("header-links.php") ?>
</head>
<body>
    <?php include("guest/header.php") ?>
    <?php include("guest/navbar.php") ?>
    <?php include("guest/slider.php") ?>
    <?php include("guest/categories.php") ?>
    <?php include("guest/featured-products.php") ?>
     <?php include("guest/footer.php") ?>





    <?php include("footer-links.php") ?>
</body>
</html>